package com.example.login_ahan;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class AnimatedGradientView extends View {

    private Paint paint = new Paint();
    private int[] colors = {
            0xFF1A1A2E, // dark navy
            0xFF6A0DAD, // purple
            0xFFD4AF37, // gold
            0xFFE94560, // pink-red
            0xFF0F3460, // deep blue
            0xFF1A1A2E  // balik lagi ke dark navy biar looping mulus
    };

    private float shift = 0f;
    private ValueAnimator animator;

    public AnimatedGradientView(Context context) {
        super(context);
    }

    public AnimatedGradientView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        startAnimation(w);
    }

    private void startAnimation(int width) {
        if (animator != null) animator.cancel();

        // total lebar virtual gradient = 2x lebar layar biar looping mulus
        animator = ValueAnimator.ofFloat(0f, width * 2f);
        animator.setDuration(2500); // makin kecil = makin cepat
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            shift = (float) animation.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();

        LinearGradient gradient = new LinearGradient(
                -w + shift, 0,
                w * 2 + shift, h,
                colors,
                null,
                Shader.TileMode.MIRROR
        );

        paint.setShader(gradient);
        canvas.drawRect(0, 0, w, h, paint);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (animator != null) animator.cancel();
    }
}